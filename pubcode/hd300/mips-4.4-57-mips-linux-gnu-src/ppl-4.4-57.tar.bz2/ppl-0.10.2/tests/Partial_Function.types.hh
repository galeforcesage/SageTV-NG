/* Copyright (C) 2001-2009 Roberto Bagnara <bagnara@cs.unipr.it>

This file is free software; as a special exception the author gives
unlimited permission to copy and/or distribute it, with or without
modifications, as long as this notice is preserved.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY, to the extent permitted by law; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. */

#ifndef PPL_Partial_Function_types_hh
#define PPL_Partial_Function_types_hh 1

namespace Parma_Polyhedra_Library {

namespace Test {

class Partial_Function;

} // namespace Test

} // namespace Parma_Polyhedra_Library

#endif // !defined(PPL_Partial_Function_types_hh)
